### Download 
Archive password is `wYMvdd6fJJVM`

### What's Changed
Full Changelog: https://github.com/flashbots/mev-boost/compare/v1.2.1...v1.3.2
Updated images are available on Docker Hub: https://hub.docker.com/r/flashbots/mev-boost